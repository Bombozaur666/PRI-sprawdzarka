from subprocess import Popen, PIPE, run
import os, re

#STEP 1 - get all the files (later from a database i guess)

location = os.getcwd() #current dir, later change to specified location

#STEP 2 - merge plikow pml i ltl

plik_pml = plik_ltl = ""

for file in os.listdir(location):
	if file.endswith(".pml") and not file.endswith("_merge.pml"):
		with open(file) as fp: #tu po kolei kazdy plik do sprawdzenia zadania danego typu
			plik_pml = fp.read()
			
		with open("np02b_ltl.txt") as fp: #wspolny plik dla wszystkich zadan danego typu
			plik_ltl = fp.read()
			
		plik_pml += "\n"
		plik_pml += plik_ltl
		
		file_new = str(file)
		file_new = file_new.replace(".pml", "_merge.pml")
		
		

		with open (file_new, 'w') as fp: #stworzylem nowe pliki dla testow nie wiem jak to chcesz zrobic docelowo czy tworzyc nowe czy nadpisywac stare
			fp.write(plik_pml)
	
#STEP 3 - skompilowanie plikow w promeli, zapisanie wydrukow

for file in os.listdir(location):
	if file.endswith("_merge.pml"):
	
		file_new = str(file)
		file_new = file_new.replace("_merge.pml", "_result.txt")
		open(file_new, 'w').close() #czysci plik zeby mozna cat uzyc nizej i nie dodawac w nieskonczonosc tekstu
		
		commands = [f'spin -a {file}', 'gcc -o pan pan.c', f'./pan -a -N L4 > {file_new}'] #TODO make it go through all LTL statements instead of one
#TODO 2 sprawic zeby drukowal bledy albo sie wypieprzal i nie drukowal nic albo cos nwm w sumie jeszcze
		processes = []
		for com in commands:
			processes.append(run(com, shell=True))
		
	

#ponizej jest kod od bombo ktory otwiera pliki z wynikami i sprawdza czy error 0 byl

lista = []
ss = []
for file in os.listdir(location):
	if file.endswith("_result.txt"):
		with open(file) as f:
			ss=f.read().splitlines()
			f.close()
		for x in ss:
			y = re.search("errors: 0", x)
			if y is not None:
				lista.append(file)
		
print(lista)
	

